const mongoose = require("mongoose");

const userAllWiseMealSchema = new mongoose.Schema(
  {
    type: String,
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "InstituteRegistration",
    },
    institute_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "InstituteRegistration",
    },
    uid: Number,
    routine_type: String,
    meals: [
      {
        day: String,
        meal_type: String,
        package_price: Number,
        start_time: String,
        end_time: String,
        is_on: Boolean,
        remember_on: { type: Boolean, default: false },
        balance_deducted: {
          type: Boolean,
          default: false,
        },
         last_deducted_date: {          // ⬅️ নতুন
          type: String,
          default: null,
        },
        is_attendance: {
          type: Boolean,
          default: false,
        },
        deduction_history: [          // ⬅️ নতুন — যোগ করুন
          {
            date: { type: String, required: true },
            amount: { type: Number, required: true },
          },
        ],
        selected_items: [
          {
            title: String,
          },
        ],
        guest_items: [{ title: String }],
        is_alternative: Boolean,
        guest_quantity: Number,
      },
    ],
  },
  {
    timestamps: true,
  },
);

userAllWiseMealSchema.index({
  "meals.day": 1,
  "meals.is_on": 1,
  "meals.balance_deducted": 1,
});

module.exports = mongoose.model("UserAllWiseMeal", userAllWiseMealSchema);
